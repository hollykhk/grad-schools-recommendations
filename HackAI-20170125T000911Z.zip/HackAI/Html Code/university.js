app.controller('universityCtrl', ['$scope', '$mdDialog',
    "$location", '$window',
    function($scope, $mdDialog, $location, $window) {

	
	
	
}]);
